﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UcakBiletiRezervasyon.Models
{
    public class Ucus
    {
        public int Id { get; set; }
        public string HavaYoluSirketi { get; set; }
        public int KalkisHavalimani { get; set; }
        public int VarisHavalimani { get; set; }
        public DateTime KalkisZamani { get; set; }
        public DateTime VarisZamani { get; set; }

    }
}