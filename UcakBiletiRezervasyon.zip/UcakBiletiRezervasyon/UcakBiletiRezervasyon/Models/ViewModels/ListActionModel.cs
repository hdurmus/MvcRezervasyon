﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UcakBiletiRezervasyon.Models.ViewModels
{
    public class ListActionModel
    {
        public string ControllerName { get; set; }
        public string Parameter { get; set; }
    }
}