﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UcakBiletiRezervasyon.Models;

namespace UcakBiletiRezervasyon.Controllers
{
    public class MusteriController : Controller
    {
        private UcakBiletContext _context;
        public MusteriController()
        {
            _context = new UcakBiletContext();
        }
        // GET: Musteri
        //[OutputCache(Duration = 100, VaryByParam = "none")]
        [CacheWriter]
        public ActionResult Index()
        {
            var list = (from musteri in _context.Musteriler
                        select new MusteriListesiDTO
                        {
                            Id = musteri.Id,
                            Isim = musteri.Isim,
                            TelNo = musteri.TelNo

                        }).ToList();
            return View(list);
        }

        [HttpGet]
        public ActionResult Create()
        {   
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Musteri musteri)
        {
            if(ModelState.IsValid)
            {
                _context.Musteriler.Add(musteri);
                _context.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        public JsonResult Delete(string id)
        {
            _context.Musteriler.Remove(_context.Musteriler.Find(id));
            _context.SaveChanges();

            var response = new JsonResponse();
            response.Status = "200";
            response.Message = "Item  deleted!";

            return Json(response, JsonRequestBehavior.AllowGet);
        }
    }
}