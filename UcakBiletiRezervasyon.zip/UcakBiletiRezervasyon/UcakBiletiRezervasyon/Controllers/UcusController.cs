﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UcakBiletiRezervasyon.Models;

namespace UcakBiletiRezervasyon.Controllers
{
    public class UcusController : Controller
    {
        private UcakBiletContext _context;
        public UcusController()
        {
            _context = new UcakBiletContext();
        }

        // GET: Ucus
        public ActionResult Index()
        {
            var list = new List<Ucus>();

            list = _context.Ucuslar.ToList();
            //using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["MyConnStr"].ConnectionString))
            //{
            //    var cmd = new SqlCommand("UcusBilgisiListe", conn);
            //    conn.Open();
            //    var reader = cmd.ExecuteReader();

            //    while (reader.Read())
            //    {
            //        var ucus = new Ucus();
            //        ucus.Id = Convert.ToInt32(reader["Id"]);
            //        ucus.HavaYoluSirketi = reader["HavaYoluSirketi"].ToString();
            //        ucus.KalkisHavalimani = Convert.ToInt32(reader["KalkisHavalimani"]);
            //        ucus.VarisHavalimani = Convert.ToInt32(reader["VarisHavalimani"]);
            //        ucus.KalkisHavalimani = Convert.ToInt32(reader["KalkisHavalimani"]);
            //        ucus.KalkisZamani = Convert.ToDateTime(reader["KalkisZamani"]);
            //        ucus.VarisZamani = Convert.ToDateTime(reader["VarisZamani"]);
            //        list.Add(ucus);
            //    }
            //    reader.Close();
            //}
            //Business Code
            return View(list);
        }

        public ActionResult UcusBilgisiEkleme()
        {
            return View();
        }

        [HttpPost]
        public ActionResult UcusBilgisiEkleme(Ucus ucus)
        {
            if (ModelState.IsValid)
            {
                _context.Ucuslar.Add(ucus);
                _context.SaveChanges();
            }
            return View();
        }

        public ActionResult UcusBilgisiDuzenleme(int id)
        {
            var ucusBilgisi = _context.Ucuslar.Find(id);
            return View(ucusBilgisi);
        }
        [HttpPost]
        public ActionResult UcusBilgisiDuzenleme(Ucus ucus)
        {
            if (ModelState.IsValid)
            {
                var eskiUcus = _context.Ucuslar.Find(ucus.Id);
                _context.Entry(eskiUcus).CurrentValues.SetValues(ucus);
                _context.SaveChanges();
            }

            var list = _context.Ucuslar.ToList();
            //return View("Index",list);
            return RedirectToAction("Index");
        }

    }
}