﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Web;

namespace UcakBiletiRezervasyon.Models
{

    public class UcakBiletContext: DbContext
    {
        public DbSet<Ucus> Ucuslar { get; set; }
        public DbSet<Musteri> Musteriler { get; set; }

        //public override int SaveChanges()
        //{
        //    return base.SaveChanges();
        //}

        //public override void OnModelCreating(DbModelBuilder modelBuilder)
        //{
        //    modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();

        //    base.OnModelCreating(modelBuilder);
        //}


    }
}