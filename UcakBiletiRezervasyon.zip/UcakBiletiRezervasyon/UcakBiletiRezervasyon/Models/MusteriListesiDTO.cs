﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UcakBiletiRezervasyon.Models
{
    public class MusteriListesiDTO
    {
        public int Id { get; set; }
        public string Isim { get; set; }
        public string TelNo { get; set; }
    }
}