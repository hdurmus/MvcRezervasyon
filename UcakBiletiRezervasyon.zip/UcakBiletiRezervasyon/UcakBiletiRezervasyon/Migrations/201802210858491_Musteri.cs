namespace UcakBiletiRezervasyon.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Musteri : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Musteris",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Isim = c.String(nullable: false),
                        Soyisim = c.String(nullable: false),
                        TCKN = c.String(nullable: false, maxLength: 11),
                        Mail = c.String(),
                        TelNo = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Musteris");
        }
    }
}
