﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace UcakBiletiRezervasyon.Models
{
    public class Musteri
    {
        public int Id { get; set; }
        [Required(ErrorMessage ="İsim alanı zorunludur.")]
        public string Isim { get; set; }
        [Required(ErrorMessage = "Soyisim alanı zorunludur.")]
        public string Soyisim { get; set; }
        [Required(ErrorMessage = "TCKN alanı zorunludur.")]
        [MaxLength(11,ErrorMessage ="TCNK 11 hane olmalı")]
        [MinLength(11, ErrorMessage = "TCNK 11 hane olmalı")]
        [RegularExpression(@"^[1-9]{1}[0-9]{10}$", ErrorMessage = "TCKN no hatalı")]
        [Display(Name = "Vatandaşlık No")]
        public string TCKN { get; set; }
        [DataType(DataType.EmailAddress)]
        public string Mail { get; set; }
        [DataType(DataType.PhoneNumber)]
        public string TelNo { get; set; }
    }
}